// Ini adalah tes widget Flutter dasar.
//
// Untuk melakukan interaksi dengan widget dalam pengujian Anda, gunakan WidgetTester
// utilitas yang disediakan Flutter. Misalnya, Anda dapat mengirim ketuk dan gulir
// gerakan. Anda juga dapat menggunakan WidgetTester untuk menemukan widget anak di widget
// membuat pohon, membaca teks, dan memverifikasi bahwa nilai properti widget sudah benar.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:covid19/main.dart';

void main() {
  testWidgets('Counter increments smoke test', (WidgetTester tester) async {
    // Bangun aplikasi kita dan picu bingkai.
    await tester.pumpWidget(MyApp());

    // Verifikasi bahwa penghitung kita dimulai dari 0.
    expect(find.text('0'), findsOneWidget);
    expect(find.text('1'), findsNothing);

    // Ketuk ikon '+' dan picu bingkai.
    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();

    // Verifikasi bahwa penghitung kami telah bertambah.
    expect(find.text('0'), findsNothing);
    expect(find.text('1'), findsOneWidget);
  });
}
