import 'package:covid19/covid19.dart';
import 'package:flutter/material.dart';

void main() {
//  runApp(MyApp());
  runApp(new MaterialApp(
    home: CoronaVirusApp(),
  ));
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
       // Ini adalah tema aplikasi Anda.
        //
        // Coba jalankan aplikasi Anda dengan "flutter run". Anda akan melihat
        // aplikasi memiliki toolbar biru. Kemudian, tanpa keluar dari aplikasi, coba
        // mengubah primarySwatch di bawah menjadi Colors.green dan kemudian memanggil
        // "hot reload" (tekan "r" di konsol tempat Anda menjalankan "flutter run",
        // atau cukup simpan perubahan Anda ke "hot reload" di Flutter IDE).
        // Perhatikan bahwa penghitung tidak direset kembali ke nol; aplikasi
        // tidak dimulai ulang.
        primarySwatch: Colors.blue,
        // Ini membuat kepadatan visual beradaptasi dengan platform yang Anda jalankan
        // aplikasi aktif. Untuk platform desktop, kontrolnya akan lebih kecil dan
        // lebih dekat (lebih padat) daripada di platform seluler.
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

 // Widget ini adalah halaman beranda aplikasi Anda. Ini stateful, artinya
  // bahwa ia memiliki objek State (didefinisikan di bawah) yang berisi bidang yang mempengaruhi
  // bagaimana tampilannya.

  // Kelas ini adalah konfigurasi untuk keadaan. Ini memegang nilai-nilai (dalam hal ini
  // kasus judul) yang disediakan oleh orang tua (dalam hal ini widget Aplikasi) dan
  // digunakan oleh metode build dari State. Bidang dalam subkelas Widget adalah
  // selalu ditandai "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      // Panggilan ke setState ini memberi tahu framework Flutter bahwa ada sesuatu
      // berubah di Status ini, yang menyebabkannya menjalankan kembali metode build di bawah ini
      // sehingga tampilan dapat mencerminkan nilai yang diperbarui. Jika kita berubah
      // _counter tanpa memanggil setState(), maka metode build tidak akan
      // dipanggil lagi, jadi sepertinya tidak ada yang terjadi.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Metode ini dijalankan kembali setiap kali setState dipanggil, misalnya seperti yang dilakukan
    // dengan metode _incrementCounter di atas.
    //
    // Framework Flutter telah dioptimalkan untuk menjalankan kembali metode build
    // cepat, sehingga Anda dapat membangun kembali apa pun yang perlu diperbarui
    // daripada harus mengubah instance widget satu per satu.
    return Scaffold(
      appBar: AppBar(
        // Di sini kita mengambil nilai dari objek MyHomePage yang dibuat oleh
        // metode App.build, dan gunakan untuk mengatur judul bilah aplikasi kita.
        title: Text(widget.title),
      ),
      body: Center(
        // Center adalah widget tata letak. Dibutuhkan satu anak dan memposisikannya
        // di tengah induk.
        child: Column(
          // Kolom juga merupakan widget tata letak. Dibutuhkan daftar anak-anak dan
          // mengaturnya secara vertikal. Secara default, ukurannya sendiri agar sesuai dengannya
          // anak-anak secara horizontal, dan mencoba setinggi orang tuanya.
          //
          // Aktifkan "debug painting" (tekan "p" di konsol, pilih
          // Tindakan "Toggle Debug Paint" dari Flutter Inspector di Android
          // Studio, atau perintah "Toggle Debug Paint" dalam Kode Visual Studio)
          // untuk melihat gambar rangka untuk setiap widget.
          //
          // Kolom memiliki berbagai properti untuk mengontrol bagaimana ukurannya dan
          // bagaimana posisi anak-anaknya. Di sini kita menggunakan mainAxisAlignment untuk
          // tengahkan anak-anak secara vertikal; sumbu utama di sini adalah vertikal
          // axis karena Kolom vertikal (sumbu silangnya adalah
          // mendatar).
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // Tanda koma ini membuat pemformatan otomatis lebih bagus untuk metode build.
    );
  }
}
